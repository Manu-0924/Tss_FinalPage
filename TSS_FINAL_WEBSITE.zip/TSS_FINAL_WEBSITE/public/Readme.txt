Thanks for downloading this template!

Template Name: Moderna
Template URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/


index lo hero section,why join us section and features section.

services page ee folder lodhi pettu

photos page ,food coupons,voulunteers-gc,culturals-gc,sports pages ee folder lovi pettu.

style sheet lo last lo changes by komala anundhi adhi paste chey and hero section na folder loni style sheet pettu

inka konni images asses/css lo unnavi akda paste chey

and inka konni img/porfolio lo portfolio1,2,3,
img folder lo food,image1,2,3, images kavali

inkonni changes unnai avi nene chestha style sheet lo